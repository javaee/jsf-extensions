package com.enverio.util;

public interface Predicate<E> {
    public boolean evaluate(E item);
}
